# HW Signal 恢复

1. `git clone git@github.com:comegome/HW-Signal.git /opt/hwsignal`
2. 解包本 tar：`site.db` → `/opt/hwsignal/data/site.db`，`config.json` → `/opt/hwsignal/config.json`
3. `sudo /opt/hwsignal/scripts/install.sh`（装 dispatch 脚本与 cron）
4. 填 `/etc/hwsignal/env`（MAGPIE_KEY）与 `/etc/hwsignal/curl-auth`（GitHub token）
5. `sudo /opt/hwsignal/run.sh`，然后 `python3 generate.py --doctor`
